"""
Data models for the USDA FDC API.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
from datetime import datetime


@dataclass
class Nutrient:
    """
    Represents a nutrient in a food item.
    """
    id: int
    name: str
    amount: float
    unit_name: str
    nutrient_nbr: Optional[int] = None
    rank: Optional[int] = None
    
    def __str__(self) -> str:
        """String representation of the nutrient."""
        return f"{self.name}: {self.amount} {self.unit_name}"
    
    @classmethod
    def from_api_data(cls, data: Dict[str, Any]) -> 'Nutrient':
        """
        Create a Nutrient instance from API data.

        FDC describes a nutrient two different ways. ``format=full`` nests it
        under a ``nutrient`` key, while ``format=abridged`` and the search
        endpoint inline the fields on the row itself. Both are handled here:
        reading only the nested shape silently dropped every nutrient of an
        abridged food.

        Args:
            data: The API response data for a nutrient.

        Returns:
            A Nutrient instance.
        """
        nutrient_data = data.get('nutrient')
        if nutrient_data:
            return cls(
                id=nutrient_data.get('id'),
                name=nutrient_data.get('name'),
                amount=data.get('amount', 0),
                unit_name=nutrient_data.get('unitName'),
                nutrient_nbr=nutrient_data.get('number'),
                rank=nutrient_data.get('rank')
            )

        # Inline shape. Abridged foods carry no nutrient id, only its number,
        # and the search endpoint names the amount "value".
        amount = data.get('amount')
        if amount is None:
            amount = data.get('value', 0)

        return cls(
            id=data.get('nutrientId'),
            name=data.get('nutrientName') or data.get('name'),
            amount=amount,
            unit_name=data.get('unitName'),
            nutrient_nbr=data.get('nutrientNumber') or data.get('number'),
            rank=data.get('rank')
        )


@dataclass
class FoodPortion:
    """
    Represents a food portion.
    """
    id: int
    amount: float
    gram_weight: float
    portion_description: Optional[str] = None
    modifier: Optional[str] = None
    measure_unit: Optional[str] = None
    
    def __str__(self) -> str:
        """String representation of the food portion."""
        return f"{self.amount} {self.measure_unit} ({self.gram_weight}g)"
    
    @classmethod
    def from_api_data(cls, data: Dict[str, Any]) -> 'FoodPortion':
        """
        Create a FoodPortion instance from API data.
        
        Args:
            data: The API response data for a food portion.
            
        Returns:
            A FoodPortion instance.
        """
        measure_unit_data = data.get('measureUnit', {})
        return cls(
            id=data.get('id'),
            amount=data.get('amount', 0),
            gram_weight=data.get('gramWeight', 0),
            portion_description=data.get('portionDescription'),
            modifier=data.get('modifier'),
            measure_unit=measure_unit_data.get('name')
        )


@dataclass
class Food:
    """
    Represents a food item from the FDC database.

    Note on ``gtin_upc``: FDC has no barcode-lookup endpoint, so callers
    looking a product up by barcode must use the full-text search, which
    returns fuzzy matches — an unknown barcode happily comes back with an
    unrelated product. ``gtin_upc`` is what lets a caller verify that a hit
    really is the barcode they asked for, rather than attributing one
    product's nutrition to another product's barcode.
    """
    fdc_id: int
    description: str
    data_type: str
    publication_date: Optional[str] = None
    food_class: Optional[str] = None
    food_category: Optional[str] = None
    scientific_name: Optional[str] = None
    brand_owner: Optional[str] = None
    brand_name: Optional[str] = None
    gtin_upc: Optional[str] = None
    ingredients: Optional[str] = None
    serving_size: Optional[float] = None
    serving_size_unit: Optional[str] = None
    household_serving_fulltext: Optional[str] = None
    nutrients: List[Nutrient] = field(default_factory=list)
    food_portions: List[FoodPortion] = field(default_factory=list)
    
    @classmethod
    def from_api_data(cls, data: Dict[str, Any], abridged: bool = False) -> 'Food':
        """
        Create a Food instance from API data.
        
        Args:
            data: The API response data for a food.
            abridged: Whether the data is in abridged format. Nutrients are
                parsed either way; this only skips food portions, which an
                abridged response does not carry.

        Returns:
            A Food instance.
        """
        food = cls(
            fdc_id=data.get('fdcId'),
            description=data.get('description', ''),
            data_type=data.get('dataType', ''),
            publication_date=data.get('publicationDate'),
            food_class=data.get('foodClass'),
            food_category=data.get('foodCategory', {}).get('description') if data.get('foodCategory') else None,
            scientific_name=data.get('scientificName'),
            brand_owner=data.get('brandOwner'),
            brand_name=data.get('brandName'),
            gtin_upc=data.get('gtinUpc'),
            ingredients=data.get('ingredients'),
            serving_size=data.get('servingSize'),
            serving_size_unit=data.get('servingSizeUnit'),
            household_serving_fulltext=data.get('householdServingFullText')
        )
        
        # Parse nutrients if present. Nutrient.from_api_data understands both
        # the nested (full) and inline (abridged) shapes, so an abridged food
        # keeps its nutrients instead of coming back silently empty.
        if 'foodNutrients' in data:
            food.nutrients = [
                Nutrient.from_api_data(nutrient)
                for nutrient in data['foodNutrients']
            ]

        # Parse food portions if present
        if 'foodPortions' in data and not abridged:
            food.food_portions = [
                FoodPortion.from_api_data(portion) 
                for portion in data['foodPortions']
            ]
        
        return food


@dataclass
class SearchResultFood:
    """
    Represents a food item in search results.
    """
    fdc_id: int
    description: str
    data_type: str
    publication_date: Optional[str] = None
    food_category: Optional[str] = None
    brand_owner: Optional[str] = None
    brand_name: Optional[str] = None
    gtin_upc: Optional[str] = None

    @classmethod
    def from_api_data(cls, data: Dict[str, Any]) -> 'SearchResultFood':
        """
        Create a SearchResultFood instance from API data.
        
        Args:
            data: The API response data for a search result food.
            
        Returns:
            A SearchResultFood instance.
        """
        return cls(
            fdc_id=data.get('fdcId'),
            description=data.get('description', ''),
            data_type=data.get('dataType', ''),
            publication_date=data.get('publicationDate'),
            food_category=data.get('foodCategory'),
            brand_owner=data.get('brandOwner'),
            brand_name=data.get('brandName'),
            gtin_upc=data.get('gtinUpc')
        )


@dataclass
class SearchResult:
    """
    Represents search results from the FDC API.
    """
    foods: List[SearchResultFood]
    total_hits: int
    current_page: int
    total_pages: int
    
    @classmethod
    def from_api_data(cls, data: Dict[str, Any]) -> 'SearchResult':
        """
        Create a SearchResult instance from API data.
        
        Args:
            data: The API response data for search results.
            
        Returns:
            A SearchResult instance.
        """
        foods = [
            SearchResultFood.from_api_data(food) 
            for food in data.get('foods', [])
        ]
        
        return cls(
            foods=foods,
            total_hits=data.get('totalHits', 0),
            current_page=data.get('currentPage', 1),
            total_pages=data.get('totalPages', 1)
        )